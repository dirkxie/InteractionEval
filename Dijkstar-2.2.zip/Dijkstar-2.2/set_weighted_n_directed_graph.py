#   '1'-5-'2'-2-'3'
#    |     |     |
#    7     3     8
#    |     |     |
#   '4'-1-'5'-6-'6'
#    |     |     |
#    3     1     4  
#    |     |     |
#   '7'-5-'8'-9-'9'

from dijkstar import Graph, find_path

graph = None 
cost_func = None

def directed_and_guided_map_init ():
  global graph
  global cost_func
  graph = Graph()
  graph.add_edge(1, 2, {'cost': 5})
  graph.add_edge(2, 1, {'cost': 5})
  graph.add_edge(2, 3, {'cost': 2})
  graph.add_edge(3, 2, {'cost': 2})

  graph.add_edge(1, 4, {'cost': 7})
  graph.add_edge(4, 1, {'cost': 7})
  graph.add_edge(2, 5, {'cost': 3})
  graph.add_edge(5, 2, {'cost': 3})
  graph.add_edge(3, 6, {'cost': 8})
  graph.add_edge(6, 3, {'cost': 8})

  graph.add_edge(4, 5, {'cost': 1})
  graph.add_edge(5, 4, {'cost': 1})
  graph.add_edge(5, 6, {'cost': 6})
  graph.add_edge(6, 5, {'cost': 6})

  graph.add_edge(4, 7, {'cost': 3})
  graph.add_edge(7, 4, {'cost': 3})
  graph.add_edge(5, 8, {'cost': 1})
  graph.add_edge(8, 5, {'cost': 1})
  graph.add_edge(6, 9, {'cost': 4})
  graph.add_edge(9, 6, {'cost': 4})

  graph.add_edge(7, 8, {'cost': 5})
  graph.add_edge(8, 7, {'cost': 5})
  graph.add_edge(8, 9, {'cost': 9})
  graph.add_edge(9, 8, {'cost': 9})

  cost_func = lambda u, v, e, prev_e: e['cost']

def main():
  directed_and_guided_map_init()
  a = find_path(graph, 1, 9, cost_func=cost_func)
  print a

main()
